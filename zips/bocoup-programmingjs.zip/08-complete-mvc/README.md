# programming-with-javascript
> Learn javascript basics by writing a hangman game.

# Setup

1. Clone repository.
2. `npm install`
3. `npm install -g grunt-cli`
4. `grunt`
5. To play game, open http://localhost:8000
6. To view tests, open http://localhost:8000/test
