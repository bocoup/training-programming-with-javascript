# programming-with-javascript
> Learn javascript basics by writing a hangman game.

## About this Exercise
Students will prompt the user for a guess and register it with the game.

### Concepts Covered
- use [`alert`](https://developer.mozilla.org/en-US/docs/Web/API/Window.alert) to deliver information to the user in the browser
- use [`prompt`](https://developer.mozilla.org/en-US/docs/Web/API/Window.prompt) to receive user input in the browser