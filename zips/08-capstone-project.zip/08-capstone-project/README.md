# Capstone Project: Tic-Tac-Toe

In this project you will build your own Tic-Tac-Toe game.

## LEVEL 1
Create a 2-player tic-tac-toe game.

## LEVEL 2
Create a random opponent to play against.

# LEVEL 3
Create an intelligent opponent to play against.
