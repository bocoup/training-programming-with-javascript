# programming-with-javascript
> Learn javascript basics by writing a hangman game.

## About this Exercise
Students will learn how to compose javascript applications using multiple files.

### Concepts Covered
