# programming-with-javascript
> Learn javascript basics by writing a hangman game.

## About this Exercise
Description of what this exercise is about.

### Concepts Covered
