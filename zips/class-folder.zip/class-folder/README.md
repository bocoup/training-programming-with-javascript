# programming-with-javascript
> Learn javascript basics by writing a hangman game.

## Setup Instructions

1. `npm install`
2. `npm install -g grunt-cli`
3. Start auto-reloading web-server for your exercise by running `grunt`.
4. Open [http://localhost:8000](http://localhost:8000) or [http://localhost:8000/test](http://localhost:8000/test]) in your browser.

## Concepts Covered
- Values and Variables
- Arithmetic Operators and the Math Object
- Strings
- Arrays
- Control Flow
- Functions 
- Browser and DOM Manipulation