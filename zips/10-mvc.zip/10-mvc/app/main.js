$(function () {
  //var Game = window.Game = new Hangman($('.hangman'));
  //Game.start();
});
