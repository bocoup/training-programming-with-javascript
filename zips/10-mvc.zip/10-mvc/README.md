# programming-with-javascript
> Learn javascript basics by writing a hangman game.

## About this Exercise
Students will implement a Hangman game using MVC.

### Concepts Covered
